package zadanieBlog;

public interface SampleInterface {

     int start();
}
